# Instructions  

Assista ao vídeo de apresentação no ambiente virtual de aprendizagem para compreender com maior clareza o que é pedido em cada questão. Como a atividade prática da semana 3 vale 20,0 pontos, cada questão vale 2,0 pontos. 

Boa atividade!